console.log("Content script running...");

// Detect video elements on the page
let videos = document.getElementsByTagName("video");

if (videos.length > 0) {
    console.log("Video detected");

    // Create a floating button for sign language player
    let button = document.createElement("button");
    button.innerText = "Show Sign Language";
    button.style.position = "fixed";
    button.style.bottom = "20px";
    button.style.right = "20px";
    button.style.zIndex = "10000";
    button.style.padding = "10px";
    button.style.backgroundColor = "#007bff";
    button.style.color = "white";
    button.style.border = "none";
    button.style.borderRadius = "5px";
    button.style.cursor = "pointer";

    document.body.appendChild(button);

    button.addEventListener("click", () => {
        chrome.runtime.sendMessage({ action: "openSignPlayer" });
    });
}
