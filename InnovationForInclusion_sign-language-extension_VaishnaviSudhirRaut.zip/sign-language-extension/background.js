chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "openSignPlayer") {
        chrome.windows.create({
            url: chrome.runtime.getURL("sign-player.html"),
            type: "popup",
            width: 320,
            height: 240
        });
    }
});
