document.getElementById("changeVideo").addEventListener("click", function () {
    let videoElement = document.getElementById("signVideo");
    
    // Array of video file names
    let videoFiles = ["A.mp4", "B.mp4", "C.mp4", "1.mp4", "2.mp4", "3.mp4"];

    // Select a random video from the array
    let randomIndex = Math.floor(Math.random() * videoFiles.length);
    let newVideoSrc = `videos/${videoFiles[randomIndex]}`;

    // Update the video source
    videoElement.src = newVideoSrc;
    videoElement.load(); // Reload the video
    videoElement.play(); // Play the new video
});
